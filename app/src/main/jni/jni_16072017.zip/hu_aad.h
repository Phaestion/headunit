
  unsigned int hu_aad_dmp (unsigned char * prefix, unsigned char * src, int chan, int flags, unsigned char * buf, int len);   // Source:  HU = HU > AA   AA = AA > HU

