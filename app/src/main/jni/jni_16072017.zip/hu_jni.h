
  int hu_usb_recv  (byte * buf, int len, int tmo);                     // Used by hu_aap:hu_aap_usb_recv ()
  int hu_usb_send  (byte * buf, int len, int tmo);                     // Used by hu_aap:hu_aap_usb_send ()